# Kubernetes

Edit the `fluentd.yaml` file inserting your Humio or Elasticsearch instance details.

Apply the configuration:

```shell
$ kubectl apply -f fluentd.yaml
```

Set up [logging integration](https://www.instana.com/docs/logging/) in Instana.